# Library Management Database System

## Internship Minor Project

A MySQL 8.0 database system for managing books, members, library branches, employees, and issue/return transactions.

### Requirements covered
- Tables for books, members and transactions
- Foreign-key relationships
- Book issue and return operations
- Overdue-book query
- Availability tracking
- Issued-book and available-book reports
- SQL joins, constraints, aggregate functions and data management

### Files
- `library_management.sql` — complete MySQL database, sample data, procedures, queries and reports
- `PROJECT_REPORT.pdf` — report structure aligned with the internship assignment
- `README.md` — setup and usage instructions

### How to run
1. Install MySQL Server and MySQL Workbench.
2. Open `library_management.sql` in MySQL Workbench.
3. Execute the complete script using the lightning/Execute button.
4. Refresh the Schemas panel and select `library_management`.
5. Run:
   `SHOW TABLES;`
6. Test the required queries in section 6 of the SQL file.
7. Test a return operation using:
   `CALL return_book(1,'2026-09-07');`
   Then verify the transaction and book availability.

### Main tables
- `branches`
- `employees`
- `members`
- `books`
- `transactions`

### Relationships
- One branch → many employees
- One member → many transactions
- One book → many historical transactions
- Each transaction connects one member with one book

### Important note
The project is designed for MySQL 8.0+. The `ENUM`, `SIGNAL`, stored procedures and `CURDATE()` features are MySQL-oriented.

### Suggested screenshots for final submission
Take screenshots from your own MySQL Workbench after execution:
1. Database/schema and tables
2. `SELECT * FROM books`
3. `SELECT * FROM members`
4. Issued books report
5. Overdue books query
6. Available books report
7. Issue/return procedure execution
8. ER diagram

Do not claim screenshots as work evidence until you have actually executed the project.
