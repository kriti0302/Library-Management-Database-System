-- ============================================================
-- LIBRARY MANAGEMENT DATABASE SYSTEM
-- Internship Minor Project | MySQL 8.0+
-- ============================================================

DROP DATABASE IF EXISTS library_management;
CREATE DATABASE library_management;
USE library_management;

-- ----------------------------
-- 1. MASTER TABLES
-- ----------------------------

CREATE TABLE branches (
    branch_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_name VARCHAR(80) NOT NULL,
    address VARCHAR(200) NOT NULL,
    phone VARCHAR(20) UNIQUE
);

CREATE TABLE employees (
    employee_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    employee_name VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL,
    salary DECIMAL(10,2) NOT NULL CHECK (salary >= 0),
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE members (
    member_id INT PRIMARY KEY AUTO_INCREMENT,
    member_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    phone VARCHAR(20) UNIQUE,
    address VARCHAR(200),
    registration_date DATE NOT NULL
);

CREATE TABLE books (
    book_id INT PRIMARY KEY AUTO_INCREMENT,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(60) NOT NULL,
    author VARCHAR(100) NOT NULL,
    publisher VARCHAR(100),
    publication_year YEAR,
    rental_price DECIMAL(8,2) NOT NULL DEFAULT 0 CHECK (rental_price >= 0),
    availability ENUM('Available','Issued') NOT NULL DEFAULT 'Available'
);

-- ----------------------------
-- 2. TRANSACTION TABLE
-- ----------------------------

CREATE TABLE transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    book_id INT NOT NULL,
    member_id INT NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE NULL,
    status ENUM('Issued','Returned') NOT NULL DEFAULT 'Issued',
    FOREIGN KEY (book_id) REFERENCES books(book_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY (member_id) REFERENCES members(member_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CHECK (due_date >= issue_date),
    CHECK (return_date IS NULL OR return_date >= issue_date)
);

CREATE INDEX idx_transactions_book ON transactions(book_id);
CREATE INDEX idx_transactions_member ON transactions(member_id);
CREATE INDEX idx_transactions_due_date ON transactions(due_date);

-- ----------------------------
-- 3. SAMPLE DATA
-- ----------------------------

INSERT INTO branches (branch_name, address, phone) VALUES
('Central Library','12 College Road, New Delhi','011-40010001'),
('North Campus Library','25 University Road, New Delhi','011-40010002'),
('South Campus Library','18 Academic Avenue, New Delhi','011-40010003');

INSERT INTO employees (branch_id, employee_name, role, salary) VALUES
(1,'Aarav Sharma','Manager',62000.00),
(1,'Meera Singh','Librarian',48000.00),
(1,'Rohan Gupta','Assistant',36000.00),
(2,'Ananya Verma','Manager',65000.00),
(2,'Kabir Malhotra','Librarian',50000.00),
(2,'Ishita Rao','Assistant',35000.00),
(3,'Aditya Kumar','Manager',60000.00),
(3,'Nisha Patel','Librarian',47000.00);

INSERT INTO members
(member_name,email,phone,address,registration_date) VALUES
('Priya Mehta','priya.mehta@example.com','9000000001','Delhi','2026-01-12'),
('Rahul Verma','rahul.verma@example.com','9000000002','Noida','2026-01-20'),
('Sneha Kapoor','sneha.kapoor@example.com','9000000003','Delhi','2026-02-03'),
('Arjun Bhatia','arjun.bhatia@example.com','9000000004','Gurugram','2026-02-15'),
('Neha Joshi','neha.joshi@example.com','9000000005','Delhi','2026-03-01'),
('Vivek Shah','vivek.shah@example.com','9000000006','Ghaziabad','2026-03-12'),
('Simran Kaur','simran.kaur@example.com','9000000007','Delhi','2026-04-04'),
('Karan Sethi','karan.sethi@example.com','9000000008','Noida','2026-04-18'),
('Riya Nair','riya.nair@example.com','9000000009','Delhi','2026-05-02'),
('Manish Jain','manish.jain@example.com','9000000010','Faridabad','2026-05-20');

INSERT INTO books
(isbn,title,category,author,publisher,publication_year,rental_price) VALUES
('9780000000001','The Great Gatsby','Classic','F. Scott Fitzgerald','Scribner',1925,8.00),
('9780000000002','Animal Farm','Classic','George Orwell','Penguin Books',1945,6.00),
('9780000000003','The Alchemist','Fiction','Paulo Coelho','HarperOne',1988,5.00),
('9780000000004','Pride and Prejudice','Classic','Jane Austen','Penguin Classics',1813,5.50),
('9780000000005','A Brief History of Time','Science','Stephen Hawking','Bantam',1988,9.00),
('9780000000006','Sapiens','History','Yuval Noah Harari','Harper',2011,10.00),
('9780000000007','Clean Code','Technology','Robert C. Martin','Prentice Hall',2008,12.00),
('9780000000008','Introduction to Algorithms','Technology','Thomas H. Cormen','MIT Press',2009,15.00),
('9780000000009','The Hobbit','Fantasy','J.R.R. Tolkien','Allen & Unwin',1937,7.00),
('9780000000010','Harry Potter and the Philosopher''s Stone','Fantasy','J.K. Rowling','Bloomsbury',1997,8.00),
('9780000000011','The Diary of a Young Girl','History','Anne Frank','Bantam',1947,6.50),
('9780000000012','The Selfish Gene','Science','Richard Dawkins','Oxford University Press',1976,9.50),
('9780000000013','Atomic Habits','Self Help','James Clear','Avery',2018,11.00),
('9780000000014','Deep Work','Self Help','Cal Newport','Grand Central Publishing',2016,10.00),
('9780000000015','To Kill a Mockingbird','Classic','Harper Lee','J.B. Lippincott',1960,7.50);

-- ----------------------------
-- 4. ISSUE/RETURN PROCEDURES
-- ----------------------------

DELIMITER $$

CREATE PROCEDURE issue_book(
    IN p_book_id INT,
    IN p_member_id INT,
    IN p_issue_date DATE,
    IN p_due_date DATE
)
BEGIN
    DECLARE v_availability VARCHAR(20);

    SELECT availability INTO v_availability
    FROM books
    WHERE book_id = p_book_id;

    IF v_availability IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Book does not exist.';
    ELSEIF v_availability <> 'Available' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Book is currently unavailable.';
    ELSEIF p_due_date < p_issue_date THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Due date cannot be before issue date.';
    ELSE
        INSERT INTO transactions(book_id,member_id,issue_date,due_date,status)
        VALUES(p_book_id,p_member_id,p_issue_date,p_due_date,'Issued');

        UPDATE books
        SET availability = 'Issued'
        WHERE book_id = p_book_id;
    END IF;
END$$

CREATE PROCEDURE return_book(
    IN p_transaction_id INT,
    IN p_return_date DATE
)
BEGIN
    DECLARE v_book_id INT;
    DECLARE v_status VARCHAR(20);

    SELECT book_id, status INTO v_book_id, v_status
    FROM transactions
    WHERE transaction_id = p_transaction_id;

    IF v_book_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Transaction does not exist.';
    ELSEIF v_status = 'Returned' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Book has already been returned.';
    ELSE
        UPDATE transactions
        SET return_date = p_return_date,
            status = 'Returned'
        WHERE transaction_id = p_transaction_id;

        UPDATE books
        SET availability = 'Available'
        WHERE book_id = v_book_id;
    END IF;
END$$

DELIMITER ;

-- ----------------------------
-- 5. DEMONSTRATION TRANSACTIONS
-- ----------------------------

CALL issue_book(3,1,'2026-08-01','2026-08-15');
CALL issue_book(7,2,'2026-08-20','2026-09-03');
CALL issue_book(9,3,'2026-08-25','2026-09-08');
CALL issue_book(11,4,'2026-08-28','2026-09-11');

-- ----------------------------
-- 6. REQUIRED PROJECT QUERIES
-- ----------------------------

-- Q1. Display all books with their availability.
SELECT book_id, isbn, title, category, author, availability
FROM books
ORDER BY title;

-- Q2. Display only currently available books.
SELECT book_id, title, category, author, rental_price
FROM books
WHERE availability = 'Available'
ORDER BY title;

-- Q3. Display all currently issued books and members.
SELECT
    t.transaction_id,
    b.title,
    m.member_name,
    t.issue_date,
    t.due_date,
    t.status
FROM transactions t
JOIN books b ON t.book_id = b.book_id
JOIN members m ON t.member_id = m.member_id
WHERE t.status = 'Issued'
ORDER BY t.due_date;

-- Q4. Find overdue books.
SELECT
    t.transaction_id,
    b.title,
    m.member_name,
    t.issue_date,
    t.due_date,
    DATEDIFF(CURDATE(), t.due_date) AS days_overdue
FROM transactions t
JOIN books b ON t.book_id = b.book_id
JOIN members m ON t.member_id = m.member_id
WHERE t.status = 'Issued'
  AND t.due_date < CURDATE()
ORDER BY days_overdue DESC;

-- Q5. Count books in each category.
SELECT category, COUNT(*) AS total_books
FROM books
GROUP BY category
ORDER BY total_books DESC, category;

-- Q6. Count issued and available books.
SELECT availability, COUNT(*) AS total_books
FROM books
GROUP BY availability;

-- Q7. Members who have never issued a book.
SELECT m.member_id, m.member_name
FROM members m
LEFT JOIN transactions t ON m.member_id = t.member_id
WHERE t.transaction_id IS NULL
ORDER BY m.member_name;

-- Q8. Most frequently issued books.
SELECT
    b.title,
    COUNT(t.transaction_id) AS issue_count
FROM books b
JOIN transactions t ON b.book_id = t.book_id
GROUP BY b.book_id, b.title
ORDER BY issue_count DESC, b.title;

-- Q9. Total rental value of returned books.
SELECT
    SUM(b.rental_price) AS total_rental_value
FROM transactions t
JOIN books b ON t.book_id = b.book_id
WHERE t.status = 'Returned';

-- Q10. Employee count by branch.
SELECT
    br.branch_id,
    br.branch_name,
    COUNT(e.employee_id) AS employee_count
FROM branches br
LEFT JOIN employees e ON br.branch_id = e.branch_id
GROUP BY br.branch_id, br.branch_name
ORDER BY br.branch_id;

-- ----------------------------
-- 7. REPORTING VIEWS
-- ----------------------------

CREATE OR REPLACE VIEW issued_books_report AS
SELECT
    t.transaction_id,
    b.isbn,
    b.title,
    m.member_id,
    m.member_name,
    t.issue_date,
    t.due_date,
    CASE
        WHEN t.due_date < CURDATE() THEN 'Overdue'
        ELSE 'On Time'
    END AS due_status
FROM transactions t
JOIN books b ON t.book_id = b.book_id
JOIN members m ON t.member_id = m.member_id
WHERE t.status = 'Issued';

CREATE OR REPLACE VIEW available_books_report AS
SELECT
    book_id, isbn, title, category, author, publisher, rental_price
FROM books
WHERE availability = 'Available';

-- View the two reports
SELECT * FROM issued_books_report;
SELECT * FROM available_books_report;

-- ----------------------------
-- 8. TEST RETURN OPERATION
-- ----------------------------
-- Example: return transaction 1 when ready.
-- CALL return_book(1,'2026-09-07');

-- After returning, verify:
-- SELECT * FROM transactions WHERE transaction_id = 1;
-- SELECT book_id,title,availability FROM books WHERE book_id = 3;
